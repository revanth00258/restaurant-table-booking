const { DataTypes } = require("sequelize");
const db = require("../config/db");

const User = db.define('Trv_Users', {
    username: { type: DataTypes.STRING },
    first_name: { type: DataTypes.STRING },
    last_name: { type: DataTypes.STRING },
    // title: { type: DataTypes.STRING },
    mailAlternateAddress: { type: DataTypes.STRING },
    uid: { type: DataTypes.STRING },
    email: { type: DataTypes.STRING },
    about: {type:DataTypes.STRING},
    submit: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    }
},{
    timestamps: false
})



module.exports = Employee;