const { DataTypes } = require("sequelize");
const db = require("../config/db");

const Employee = db.define('LPA_Employes', {
    username: { type: DataTypes.STRING },
    first_name: { type: DataTypes.STRING },
    last_name: { type: DataTypes.STRING },
    // title: { type: DataTypes.STRING },
    mailAlternateAddress: { type: DataTypes.STRING },
    rtxUserPrincipalName: { type: DataTypes.STRING },
    userPrincipalName: { type: DataTypes.STRING },
    rtxID: { type: DataTypes.STRING },
    uid: { type: DataTypes.STRING },
    email: { type: DataTypes.STRING },
    is_admin: { type: DataTypes.BOOLEAN },
    is_planner: { type: DataTypes.BOOLEAN },
    is_auditor: { type: DataTypes.BOOLEAN },
    active_in : { type: DataTypes.BOOLEAN }
},{
    timestamps: false
})



module.exports = Employee;