const Sbu = require('./Sbu');
const Site = require('./Site');
const EmpAssigednList = require('./EmpAssigednList');
const Status = require('./Status');
const Employee = require('./Employee.js');
const AuditType = require('./AuditType');
const ChecklistQuestionr = require('./ChecklistQuestionr');
const Questions = require('./Questions')
const RecurrencePattern = require('./ScheduleAppointments/RecurrencePattern');
const Weeks = require('./ScheduleAppointments/Weeks.js');
const Years = require('./ScheduleAppointments/Years');
const Months = require('./ScheduleAppointments/Months');
const Days = require('./ScheduleAppointments/Days');
const AuditRecurrence = require('./AuditRecurrence');
const QuestionType = require('./QuestionTypes');
const CatgeoryType = require('./Category');
const Checklist = require('./Checklist');
const AuditQuestionr = require('./AuditQuestionr');
const _AuditFrom_ = require('./AuditFrom_');
const LpaCellCreation = require('./Cell');
const LpaCelLayerAudit = require('./Layer');
const LpaCelLayerEmpAudit = require('./CellLayerEmpAudt');

/*---- Checklist Creation */
Sbu.hasOne(Checklist, {
    foreignKey: 'sbu_id'
});
Checklist.belongsTo(Sbu, {
    foreignKey: 'sbu_id'
});
Site.hasOne(Checklist, {
    foreignKey: 'site_id'
});
Checklist.belongsTo(Site, {
    foreignKey: 'site_id'
});
Checklist.hasOne(ChecklistQuestionr, {
    foreignKey: 'checklst_id'
});
ChecklistQuestionr.belongsTo(Checklist, {
    foreignKey: 'checklst_id'
});
QuestionType.hasOne(ChecklistQuestionr, {
    foreignKey: 'quest_type_id'
});
ChecklistQuestionr.belongsTo(QuestionType, {
    foreignKey: 'quest_type_id'
});
Questions.hasOne(ChecklistQuestionr, {
    foreignKey: 'quest_id'
});
ChecklistQuestionr.belongsTo(Questions, {
    foreignKey: 'quest_id'
});
/*---- Checklist Creation */
/*---- Questionr Creation of Standard and Suplement */
// Site.hasOne(Questions, {
//     foreignKey: 'site_id'
// });
// Questions.belongsTo(Site, {
//     foreignKey: 'site_id'
// });
// Sbu.hasOne(Questions, {
//     foreignKey: 'sbu_id'
// });
// Questions.belongsTo(Sbu, {
//     foreignKey: 'sbu_id'
// });
QuestionType.hasOne(Questions, {
    foreignKey: 'quest_type_id'
});
Questions.belongsTo(QuestionType, {
    foreignKey: 'quest_type_id'
});
CatgeoryType.hasOne(Questions, {
    foreignKey: 'ctgry_type_id'
});
Questions.belongsTo(CatgeoryType, {
    foreignKey: 'ctgry_type_id'
});
/*---- Adding Questionr of Standard and Suplement */
Sbu.hasOne(Site, {
    foreignKey: 'sbu_id'
});
Site.belongsTo(Sbu, {
    foreignKey: 'sbu_id'
});

/*---- Employee Site Assign Relation */
Employee.hasOne(EmpAssigednList, {
    foreignKey: 'emp_id'
});
EmpAssigednList.belongsTo(Employee, {
    foreignKey: 'emp_id'
});
Sbu.hasOne(EmpAssigednList, {
    foreignKey: 'sbu_id'
});
EmpAssigednList.belongsTo(Sbu, {
    foreignKey: 'sbu_id'
});
Site.hasOne(EmpAssigednList, {
    foreignKey: 'site_id'
});
EmpAssigednList.belongsTo(Site, {
    foreignKey: 'site_id'
});
/*---- Employee Site Assign Relation */

/*---- Cell Creation */

Site.hasOne(LpaCellCreation, {
    foreignKey: 'site_id'
});
LpaCellCreation.belongsTo(Site, {
    foreignKey: 'site_id'
});

Sbu.hasOne(LpaCellCreation, {
    foreignKey: 'sbu_id'
});
LpaCellCreation.belongsTo(Sbu, {
    foreignKey: 'sbu_id'
});
LpaCellCreation.hasOne(LpaCelLayerAudit, {
    foreignKey: 'cell_id'
});
LpaCelLayerAudit.belongsTo(LpaCellCreation, {
    foreignKey: 'cell_id'
});
RecurrencePattern.hasOne(LpaCelLayerAudit, {
    foreignKey: 'recur_pattr_id'
});
LpaCelLayerAudit.belongsTo(RecurrencePattern, {
    foreignKey: 'recur_pattr_id'
});
Employee.hasOne(LpaCelLayerAudit, {
    foreignKey: 'emp_user_id'
});
LpaCelLayerAudit.belongsTo(Employee, {
    foreignKey: 'emp_user_id'
});
Checklist.hasOne(LpaCelLayerAudit, {
    foreignKey: 'checklst_id'
});
LpaCelLayerAudit.belongsTo(Checklist, {
    foreignKey: 'checklst_id'
});

LpaCellCreation.hasOne(LpaCelLayerEmpAudit, {
    foreignKey: 'emp_cell_id'
});
LpaCelLayerEmpAudit.belongsTo(LpaCellCreation, {
    foreignKey: 'emp_cell_id'
});

LpaCelLayerAudit.hasOne(LpaCelLayerEmpAudit, {
    foreignKey: 'emp_layer_id'
});
LpaCelLayerEmpAudit.belongsTo(LpaCelLayerAudit, {
    foreignKey: 'emp_layer_id'
});

Employee.hasOne(LpaCelLayerEmpAudit, {
    foreignKey: 'empl_id'
});
LpaCelLayerEmpAudit.belongsTo(Employee, {
    foreignKey: 'empl_id'
});
/*---- Cell Creation */
/* --- Audit Form ---- */
Site.hasOne(_AuditFrom_, {
    foreignKey: 'site_id'
});
_AuditFrom_.belongsTo(Site, {
    foreignKey: 'site_id'
});
Sbu.hasOne(_AuditFrom_, {
    foreignKey: 'sbu_id'
});
_AuditFrom_.belongsTo(Sbu, {
    foreignKey: 'sbu_id'
});
Checklist.hasOne(_AuditFrom_, {
    foreignKey: 'checklist_id'
});
_AuditFrom_.belongsTo(Checklist, {
    foreignKey: 'checklist_id'
});
LpaCellCreation.hasOne(_AuditFrom_, {
    foreignKey: 'cell_id'
});
_AuditFrom_.belongsTo(LpaCellCreation, {
    foreignKey: 'cell_id'
});
LpaCelLayerAudit.hasOne(_AuditFrom_, {
    foreignKey: 'layer_id'
});
_AuditFrom_.belongsTo(LpaCelLayerAudit, {
    foreignKey: 'layer_id'
});
_AuditFrom_.hasOne(AuditQuestionr, {
    foreignKey: 'audit_id'
});
AuditQuestionr.belongsTo(_AuditFrom_, {
    foreignKey: 'audit_id'
});
Questions.hasOne(AuditQuestionr, {
    foreignKey: 'questn_id'
});
AuditQuestionr.belongsTo(Questions, {
    foreignKey: 'questn_id'
});

AuditRecurrence.hasOne(_AuditFrom_, {
    foreignKey: 'audit_recurr_id'
});
_AuditFrom_.belongsTo(AuditRecurrence, {
    foreignKey: 'audit_recurr_id'
});

/* --- Audit Form ---- */
/* ----- Audit Recurrence ---*/
Employee.hasOne(AuditRecurrence, {
    foreignKey: 'audtr_userid'
});
AuditRecurrence.belongsTo(Employee, {
    foreignKey: 'audtr_userid'
});
LpaCelLayerAudit.hasOne(AuditRecurrence, {
    foreignKey: 'layer_id'
});
AuditRecurrence.belongsTo(LpaCelLayerAudit, {
    foreignKey: 'layer_id'
});
LpaCellCreation.hasOne(AuditRecurrence, {
    foreignKey: 'cell_id'
});
AuditRecurrence.belongsTo(LpaCellCreation, {
    foreignKey: 'cell_id'
});
RecurrencePattern.hasOne(AuditRecurrence, {
    foreignKey: 'recurrence_type_id'
});
AuditRecurrence.belongsTo(RecurrencePattern, {
    foreignKey: 'recurrence_type_id'
});
Site.hasOne(AuditRecurrence, {
    foreignKey: 'site_id'
});
AuditRecurrence.belongsTo(Site, {
    foreignKey: 'site_id'
});
Sbu.hasOne(AuditRecurrence, {
    foreignKey: 'sbu_id'
});
AuditRecurrence.belongsTo(Sbu, {
    foreignKey: 'sbu_id'
});
Checklist.hasOne(AuditRecurrence, {
    foreignKey: 'checklst_id'
});
AuditRecurrence.belongsTo(Checklist, {
    foreignKey: 'checklst_id'
});
/*---- Audit Recurrence ----- */
Sbu.sync({ alter: true });
Site.sync({ alter: true });
EmpAssigednList.sync({ alter: true });
LpaCellCreation.sync({ alter: true });
LpaCelLayerAudit.sync({ alter: true });
ChecklistQuestionr.sync({ alter: true });
Questions.sync({ alter: true });
Days.sync({ alter: true });
Weeks.sync({ alter: true });
Years.sync({ alter: true });
Status.sync({ alter: true });
Months.sync({ alter: true });
Employee.sync({ alter: true });
AuditType.sync({ alter: true });
RecurrencePattern.sync({ alter: true });
AuditRecurrence.sync({ alter: true });
QuestionType.sync({ alter: true });
CatgeoryType.sync({ alter: true });
Checklist.sync({ alter: true });
_AuditFrom_.sync({ alter: true });
AuditQuestionr.sync({ alter: true });
LpaCelLayerEmpAudit.sync({alter:true});
