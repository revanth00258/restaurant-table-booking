const log4js = require("log4js");
const { Op } = require("sequelize");
//const Employee = require("./models/User");
const logger = log4js.getLogger();

exports.addEmployee = async (req, res) => {
  const {
    username,
    first_name,
    last_name ,
    mailAlternateAddress,
    uid,
    email,
    about,
    submit,
  } = req.body;
  try {
    const employee = await Employee.create({
      username, 
    first_name,
    last_name ,
    mailAlternateAddress,
    uid,
    email,
    about,
    submit,
    });
    logger.info(`Added an employee with user id: ${user_id}`);
    return res.status(200).json(employee);
  } catch (err) {
    logger.error(`${error} - ${new Error().stack}`);
    res.json({ "Error": "Failed to add an employee with user id" }).status(500);
  }
};

exports.getEmployees = async (req, res) => {
  try {
    const employees = await Employee.findAll({
      where: {
        [Op.or]: [{ active_in: true }],
      },
    });
    logger.info(`Fetched all the employees`);
    return res.status(200).json(employees);
  } catch (err) {
    logger.error(`${error} - ${new Error().stack}`);
    res.json({ "Error": "Failed to fetch all the employees" }).status(500);
  }
};

exports.getEmployee = async (req, res) => {
  const employeeId = req.params.employeeId;
  try {
    const employee = await Employee.findOne({
      where: {
        id: email,
      },
    });
    logger.info(`Fetched details of an employee with id: ${email}`);
    return res.status(200).json(employee);
  } catch (err) {
    logger.error(`${error} - ${new Error().stack}`);
    res.json({ "Error": "Failed to fetch details of employee with id" }).status(500);
  }
};

exports.updateEmployee = async (req, res) => {
  const employeeId = req.params.employeeId;
  const {
  username,
    first_name,
    last_name ,
    mailAlternateAddress,
    uid,
    email,
    about,
    submit,
  } = req.body;
  try {
    const employee = await Employee.update(
      {
        username,
        first_name,
        last_name ,
        mailAlternateAddress,
        uid,
        email,
        about,
        submit,
      },
      {
        where: {
          id: email,
        },
      }
    );
    logger.info(
      `Update employee details of an employee with id: ${email}`
    );
    return res.status(200).json(employee);
  } catch {
    logger.error(`${error} - ${new Error().stack}`);
    res.json({ "Error": "Failed to update employee details for an employee with id" }).status(500);
  }
};










