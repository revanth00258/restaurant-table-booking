const express = require('express');
const router = express.Router();
const empCtrl = require('../controllers/employee');

const use = fn => (req, res, next) =>
    Promise.resolve(fn(req, res, next)).catch(next);

router.post('', use(empCtrl.addEmployee));
router.get('', use(empCtrl.getEmployees));
router.get('/:employeeId', use(empCtrl.getEmployee));
router.put('/:employeeId', use(empCtrl.updateEmployee));

module.exports = router;
