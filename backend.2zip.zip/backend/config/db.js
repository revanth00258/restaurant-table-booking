const Sequelize = require("sequelize");
const config = require("config");
const log4js = require("log4js");
//const colors = require("colors/safe");
const logger = log4js.getLogger();
logger.level = "debug";

const dbName = config.get("dbName");
const dbUser = config.get("dbUser");
const dbPassword = config.get("dbPassword");

module.exports = new Sequelize(dbName, dbUser, dbPassword, {
  host: "localhost",
  dialect: "mssql",
  retry: {
    match: [/Deadlock/i],
    max: 3, // Maximum rety 3 times
    backoffBase: 1000, // Initial backoff duration in ms. Default: 100,
    backoffExponent: 1.5, // Exponent to increase backoff each try. Default: 1.1
  },
  logging: false,
  loggingOptions: {
      benchmark: true,
      logging: (logStr, execTime, options) => {
          if (!options) {
              options = execTime;
              execTime = undefined;
          }
          let col = null;

        //   switch (options.type) {
        //       case 'SELECT':
        //           col = colors.blue.bold;
        //           col = colors.blue.bold;
        //           col = colors.blue.bold;
        //           break;
        //       case 'UPDATE':
        //           col = colors.yellow.bold;
        //           break;
        //       case 'INSERT':
        //           col = colors.green.bold;
        //           break;
        //       default:
        //           col = colors.white.bold;
        //           break;
        //   }
        //   if (execTime) {
        //       if (execTime >= 10) {
        //           col = colors.red.bold;
        //           logger.info(colors.magenta.bold(`[${execTime} ms]`), col(logStr));
        //       } else {
        //           logger.info(col(logStr));
        //       }
        //   }
      }
  },
  dialectOptions: {
    ssl: false,
    options: { requestTimeout: 400000 },
  },
  pool: {
    max: 1000,
    min: 0,
    acquire: 1000 * 1200,
    idle: 1000 * 1000,
    evict: 10000,
  },
  timezone: "+05:30",
});